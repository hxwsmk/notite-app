import tkinter as tk
from tkinter import messagebox, scrolledtext
import requests

print("Scriptul a pornit")

BASE_URL = "http://127.0.0.1:5000"
token = None

def login():
    global token
    username = entry_user.get()
    password = entry_pass.get()

    try:
        res = requests.post(f"{BASE_URL}/login", json={"username": username, "password": password})
        if res.status_code == 200:
            token = res.json()["token"]
            messagebox.showinfo("Succes", "Login reușit!")
            show_notes_ui()
        else:
            messagebox.showerror("Eroare", "Login eșuat!")
    except:
        messagebox.showerror("Eroare", "Serverul nu merge?")

def register():
    username = entry_user.get()
    password = entry_pass.get()

    try:
        res = requests.post(f"{BASE_URL}/register", json={"username": username, "password": password})
        if res.status_code == 201:
            messagebox.showinfo("Succes", "Cont creat! Acum te poți loga.")
        else:
            messagebox.showerror("Eroare", res.json().get("msg", "Eroare necunoscută"))
    except:
        messagebox.showerror("Eroare", "Nu s-a putut conecta la server.")

def get_notes():
    if not token:
        return
    res = requests.get(f"{BASE_URL}/notes", headers={"Authorization": f"Bearer {token}"})
    if res.status_code == 200:
        notes = res.json()
        note_list.delete("1.0", tk.END)
        for n in notes:
            note_list.insert(tk.END, f"- {n['content']}\n")
    else:
        messagebox.showerror("Eroare", "Nu s-au putut încărca notițele.")

def add_note():
    text = note_entry.get("1.0", tk.END).strip()
    if not text:
        return
    res = requests.post(f"{BASE_URL}/notes", 
                        headers={"Authorization": f"Bearer {token}"},
                        json={"content": text})
    if res.status_code == 201:
        note_entry.delete("1.0", tk.END)
        get_notes()
    else:
        messagebox.showerror("Eroare", "Nu s-a putut adăuga notița.")

# ====== UI ======
root = tk.Tk()
root.title("Notițe - Login sau Register")
root.geometry("300x230")

tk.Label(root, text="Username:").pack()
entry_user = tk.Entry(root)
entry_user.pack()

tk.Label(root, text="Parolă:").pack()
entry_pass = tk.Entry(root, show="*")
entry_pass.pack()

tk.Button(root, text="Login", command=login).pack(pady=5)
tk.Button(root, text="Înregistrează-te", command=register).pack(pady=5)

def add_note():
    text = note_entry.get("1.0", tk.END).strip()
    if not text:
        messagebox.showwarning("Atenție", "Notița e goală!")
        return
    try:
        res = requests.post(
            f"{BASE_URL}/notes",
            headers={"Authorization": f"Bearer {token}"},
            json={"content": text}
        )
        if res.status_code == 201:
            messagebox.showinfo("Succes", "Notița a fost adăugată!")
            note_entry.delete("1.0", tk.END)
            get_notes()
        else:
            messagebox.showerror("Eroare", f"Cod {res.status_code}:\n{res.text}")
    except Exception as e:
        messagebox.showerror("Eroare", str(e))


def show_notes_ui():
    for widget in root.winfo_children():
        widget.destroy()

    root.title("Notițele Mele")
    root.geometry("400x400")

    global note_list, note_entry

    note_list = scrolledtext.ScrolledText(root, height=10)
    note_list.pack(pady=10)

    note_entry = scrolledtext.ScrolledText(root, height=4)
    note_entry.pack(pady=5)

    tk.Button(root, text="Adaugă Notiță", command=add_note).pack()
    tk.Button(root, text="Reîncarcă Notițele", command=get_notes).pack(pady=5)

    get_notes()

root.mainloop()
